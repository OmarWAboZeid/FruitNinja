package View;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.scene.image.Image;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public interface FruitInterfaceFactory {
    public void move();
    public void stopMoving();
    public void resume();
    public int getEnd_x();
    public boolean getisSliced();
    public void setisSlicedF(boolean isSliced);
    public Circle Circle();
    public Image getImage();
    public void setImage(Image image);
    public String toString();

}
