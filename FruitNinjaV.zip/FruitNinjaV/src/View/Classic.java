package View;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Classic{
    int nums = 0;
    private int score = 0;
    private int fails = 0;
    private int lives = 4;
    private int randomnumber;
    private Button pause;
    private Button resume;
    private Button restart;
    private Text scoreLabel;
    private Text scoreText;
    private Text failLabel;
    private Text failText;
    private Text livesLabel;
    private Text livesText;
    private List<FruitInterfaceFactory> myArray = new ArrayList<>();
    private FruitFactory fruitFactory = new FruitFactory();
    private Group group;
    private Screen screen;
    private Rectangle2D bounds;
    private Circle cursor;

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    private Scene scene;
    private Line l;
    private Timeline timeline;
    private AudioClip heart;
    private AudioClip throwbomb;
    private AudioClip throwfruit;
    private int duration;
    private Timeline timeline2;
    private Image split = new Image("Assets/kisspng-abdel-fattah-el-sisi-egyptian-presidential-electio-5b29d2252809d7.104900651529467429164.png");
    // BackgroundImage backgroundImage = new BackgroundImage(image4);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
//Event handler to check for cursor intersection with objects
    public void PrepareClassicScene()
    {
        heart = new AudioClip(Paths.get("src/Assets/za3ama.mp3").toUri().toString());
        throwbomb = new AudioClip(Paths.get("src/Assets/Throw-bomb.wav").toUri().toString());
        throwfruit = new AudioClip(Paths.get("src/Assets/Throw-fruit.wav").toUri().toString());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Labels for showing if the score or number of fails has increased
        scoreLabel = new Text("Score: ");
        scoreLabel.setFill(Color.WHITE);
        scoreLabel.setStyle("-fx-font: 24 arial;");
        scoreLabel.setLayoutX(100);
        scoreLabel.setLayoutY(100);

        scoreText = new Text("");
        scoreText.setFill(Color.WHITE);
        scoreText.setStyle("-fx-font: 24 arial;");
        scoreText.setLayoutX(190);
        scoreText.setLayoutY(100);

        failLabel = new Text("Fails: ");
        failLabel.setFill(Color.WHITE);
        failLabel.setStyle("-fx-font: 24 arial;");
        failLabel.setLayoutX(100);
        failLabel.setLayoutY(150);

        failText = new Text("");
        failText.setFill(Color.WHITE);
        failText.setStyle("-fx-font: 24 arial;");
        failText.setLayoutX(190);
        failText.setLayoutY(150);

        livesLabel = new Text("Lives: ");
        livesLabel.setFill(Color.WHITE);
        livesLabel.setStyle("-fx-font: 24 arial;");
        livesLabel.setLayoutX(500);
        livesLabel.setLayoutY(100);

        livesText = new Text("" + lives);
        livesText.setFill(Color.WHITE);
        livesText.setStyle("-fx-font: 24 arial;");
        livesText.setLayoutX(590);
        livesText.setLayoutY(100);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

        pause = new Button("Pause");
        resume = new Button("Resume");
        restart = new Button("Restart");
        resume.setLayoutX(50);
        restart.setLayoutX(150);

        screen = Screen.getPrimary();
        bounds = screen.getVisualBounds();
        l = new Line(0, bounds.getMaxY(), bounds.getMaxX(), bounds.getMaxY());
        l.setStroke(Color.AQUA);
        cursor = new Circle(10, 10, 10, Color.GREEN);

        group = new Group();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Group for adding all the visuals to the scene
        group.getChildren().addAll(pause, resume, l, scoreText, failText, scoreLabel, failLabel, restart, livesText, livesLabel);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        scene = new Scene(group, bounds.getWidth(), bounds.getHeight());

        scene.setFill(Color.BLACK);
        Image imagecur = new Image("Assets/blade.png");
        scene.setCursor(new ImageCursor(imagecur));
        fruitFactory.setBounds(bounds);


        Image image4 = new Image("Assets/background.png");
        scene.setFill(new ImagePattern(image4));

        swipe(); //Starts checking if the fruits are sliced


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
//Timeline for creating new objects

        timeline = new Timeline(new KeyFrame(Duration.ZERO, event -> { //randomnumber= random.nextInt((max - min) + 1) + min; // spare method if you want to include numbers within a certain range.
            Random random = new Random();
            int max = 10;
            randomnumber = random.nextInt(5); // Generates a random number between 0 and 5 inclusive
            for (int i = 0; i < myArray.size(); i++) {
                group.getChildren().remove(myArray.get(i).Circle());

            }
            myArray.clear();

            for (int i = 0; i < randomnumber; i++) {
                myArray.add(fruitFactory.getFruit("strawberry", "normal"));
                myArray.get(i).move();
            }
            int lastSize = myArray.size();                                           ///This procedure is used we add new elements to the end of the array list,(where we stopped), so that the objects in the array list won't get overridden
            for (int i = myArray.size(); i < lastSize + random.nextInt(5); i++) {
                myArray.add(fruitFactory.getFruit("grape", "normal"));
                myArray.get(i).move();
            }

            lastSize = myArray.size();
            for (int i = myArray.size(); i < lastSize + random.nextInt(5); i++) {
                myArray.add(fruitFactory.getFruit("apple", "normal"));
                myArray.get(i).move();

            }

            lastSize = myArray.size();
            for (int i = myArray.size(); i < lastSize + random.nextInt(2); i++) {
                myArray.add(fruitFactory.getFruit("FatalBomb", "normal"));
                myArray.get(i).move();

            }

            lastSize = myArray.size();
            for (int i = myArray.size(); i < lastSize + random.nextInt(2); i++) {
                myArray.add(fruitFactory.getFruit("heart", "normal"));
                myArray.get(i).move();

            }
            lastSize = myArray.size();
            for (int i = myArray.size(); i < lastSize + random.nextInt(2); i++) {
                myArray.add(fruitFactory.getFruit("starfruit", "normal"));
                myArray.get(i).move();
            }

            lastSize = myArray.size();
            for (int i = myArray.size(); i < lastSize + random.nextInt(2); i++) {
                myArray.add(fruitFactory.getFruit("bomb", "normal"));
                myArray.get(i).move();
            }


            for (int i = 0; i < myArray.size(); i++) {
                group.getChildren().addAll(myArray.get(i).Circle());
            }

// Bugged
// for(int i=0; i<myArray.size();i++)
// {
//	 throwfruit.play();
// }
        }),
                new KeyFrame(Duration.seconds(5))
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
//Timeline for checking falling objects
        timeline2 = new Timeline(new KeyFrame(Duration.ZERO, event -> {
            for (int i = 0; i < myArray.size(); i++) {
                if (((myArray.get(i).getEnd_x() - (int) myArray.get(i).Circle().getCenterX()) == 400 || myArray.get(i).getEnd_x() == (int) myArray.get(i).Circle().getCenterX())) {

                    if (myArray.get(i).toString().equals("FatalBomb")) //If the fallen item is a FatalBomb, just remove it from the array, and the group
                    {
                        group.getChildren().remove(myArray.get(i).Circle());
                        myArray.remove(myArray.get(i));
                    } else if (myArray.get(i).toString().equals("starfruit")) //If the fallen item is a starfruit, just remove it from the array, and the group
                    {
                        group.getChildren().remove(myArray.get(i).Circle());
                        myArray.remove(myArray.get(i));
                    } else if (myArray.get(i).toString().equals("bomb")) //If the fallen item is a bomb, just remove it from the array, and the group
                    {
                        group.getChildren().remove(myArray.get(i).Circle());
                        myArray.remove(myArray.get(i));
                    } else if (myArray.get(i).getImage() == split) //If the fallen item is a sliced fruit, just remove it from the array, and the group
                    {

                        group.getChildren().remove(myArray.get(i).Circle());
                        myArray.remove(myArray.get(i));
                    } else { //If the item is not a special fruit
                        group.getChildren().remove(myArray.get(i).Circle());
                        myArray.remove(myArray.get(i));
                        fails++;
                        lives--;
                        failText.setText("" + fails);
                        livesText.setText("" + lives);
                    }
                }
            }
            if (lives == 0) {
                scene.setOnMouseDragged(null);
                timeline2.stop();
                stop();
            }
        }),
                new KeyFrame(Duration.millis(10)));
        timeline2.setCycleCount(Timeline.INDEFINITE);
        timeline2.play();
////
//*
///////
//*
///////
//*
///////
//*
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////


        pause.setOnAction(e -> {
            scene.setOnMouseDragged(null);
            timeline.pause();
            for (int i = 0; i < myArray.size(); i++)
                myArray.get(i).stopMoving();

        });

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

        resume.setOnAction(e -> {
            if (timeline.getStatus().toString().equals("PAUSED")) {
                swipe();
                timeline.play();
                for (int i = 0; i < myArray.size(); i++)
                    myArray.get(i).resume();
            } else {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Note");
                alert.setHeaderText("Already running");
                alert.setContentText("Game is already running");
                alert.showAndWait();
            }
        });

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Not working properly
        restart.setOnAction(e -> {
            timeline.stop();
            for (int i = 0; i < myArray.size(); i++) {
                group.getChildren().remove(myArray.get(i).Circle());
            }
            myArray.clear();
            score = 0;
            fails = 0;
            scoreText.setText("");
            failText.setText("");
            timeline.setDelay(Duration.seconds(2));
            timeline.play();
            timeline2.play();
            swipe();
        });
    }
    public void swipe() {
        scene.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                cursor.setCenterX(event.getSceneX());
                cursor.setCenterY(event.getSceneY());

                for (int i = 0; i < myArray.size(); i++) {
                    if (cursor.getBoundsInParent().intersects(myArray.get(i).Circle().getBoundsInParent())) {

                        if (myArray.get(i).toString().equals("FatalBomb")) //If the sliced fruit is a fatal bomb, stop the game.
                        {
                            stop();

                        } else if (myArray.get(i).toString().equals("heart") && myArray.get(i).getisSliced() == false) //If the sliced fruit is a heart, add one more live.
                        {
                            lives++;
                            livesText.setText("" + lives);
                            myArray.get(i).setImage(split);
                            myArray.get(i).setisSlicedF(true);
                            heart.play();

                        } else if (myArray.get(i).toString().equals("starfruit") && myArray.get(i).getisSliced() == false) //If the sliced fruit is a starfruit, add 100 points to the score.
                        {

                            score = score + 100;
                            scoreText.setText("" + score);
                            myArray.get(i).setImage(split);
                            myArray.get(i).setisSlicedF(true);
                        } else if (myArray.get(i).toString().equals("bomb") && myArray.get(i).getisSliced() == false) //If the sliced fruit is a bomb, decrease the lives by 1.
                        {

                            lives--;
                            livesText.setText("" + lives);
                            myArray.get(i).setImage(split);
                            myArray.get(i).setisSlicedF(true);
                        } else if (myArray.get(i).getisSliced() == false) //If the sliced fruit is just a normal fruit, increase the score once.
                        {
                            myArray.get(i).setImage(split);
                            myArray.get(i).setisSlicedF(true);
                            score++;
                            scoreText.setText("" + score);
                        } else {


                        }

                    }
                }


            }
        });

    }

    ////
//*
///////
//*
///////
//*
///////
//*
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
//Method to stop objects from moving
    public void stop() {
        timeline.stop();

        for (int j = 0; j < myArray.size(); j++) {
            myArray.get(j).stopMoving();
        }

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Note");
        alert.setHeaderText("YOU LOSE");
        alert.setContentText("somak");
        scene.setOnMouseDragged(null);
        alert.show();
    }
////
//*
///////
//*
///////
//*
///////
//*
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//*
}