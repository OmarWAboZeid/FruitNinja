package View;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args){
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        Classic classic = new Classic();
        MainMenu mainMenu = new MainMenu();
        //classic.PrepareClassicScene();
        mainMenu.PrepareMainmenuscene();
        mainMenu.setStage(primaryStage);
        mainMenu.setClassic(classic);
        primaryStage.setScene(mainMenu.getMainmenuscene());
        primaryStage.show();
    }
}
