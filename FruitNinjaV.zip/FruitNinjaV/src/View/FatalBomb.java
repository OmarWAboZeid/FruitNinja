package View;

import java.util.Random;

import javafx.animation.*;
import javafx.geometry.Rectangle2D;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class FatalBomb implements FruitInterfaceFactory{
    int start_x;
    int start_y;
    int end_x;
    int end_y;
    double radius;
    int speed;
    Image image;
    Random random = new Random();
    Circle circle;
    Rectangle2D bounds;
    boolean isSliced= false;
    private final Timeline timeline = new Timeline();
    private final Timeline timeline2 = new Timeline();

    public FatalBomb() {
    }
    public FatalBomb(Rectangle2D bounds, String mode) {
        this.start_x = 50+random.nextInt((int) bounds.getMaxX());
        this.start_y = (int) bounds.getMaxY();
        this.bounds=bounds;
        this.end_x = this.start_x+200;
        this.end_y =  -500+ random.nextInt((int)bounds.getMaxY());
        this.radius = 30;
        this.circle = new Circle(this.start_x,this.start_y,this.radius);
        this.image = new Image("Assets/Untitled-1.png");
        this.circle.setFill(new ImagePattern(this.image));
        if(mode.equals("normal"))
        {
        this.speed= 3500+ random.nextInt(1500);
        }
        else if (mode.equals("faster")){
        	this.speed=2500;
        }
        else if (mode.equals("fastest")){
        	this.speed=2400;
        }

        DropShadow dropShadow = new DropShadow();
        dropShadow.setOffsetX(10);
        dropShadow.setOffsetY(10);
        dropShadow.setColor(Color.BLACK);
        this.circle.setEffect(dropShadow);

        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(3));
        rotateTransition.setFromAngle(360);
        rotateTransition.setToAngle(0);
        rotateTransition.setAutoReverse(false);
        rotateTransition.setCycleCount(10000000);
        rotateTransition.setNode(this.circle);
        rotateTransition.play();

    }
    /**
     * @return the start_x
     */
    public boolean getisSliced()
    {
    	return isSliced;
    }
    public void setisSlicedF(boolean isSliced)
    {
    	this.isSliced=isSliced;
    }

    public int getStart_x() {
        return start_x;
    }
    /**
     * @return the start_y
     */
    public int getStart_y() {
        return start_y;
    }
    /**
     * @return the end_x
     */
    public int getEnd_x() {
        return end_x;
    }
    /**
     * @return the end_y
     */
    public int getEnd_y() {
        return end_y;
    }
    /**
     * @return the radius
     */
    public double getRadius() {
        return radius;
    }
    /**
     * @return the image
     */
    public Image getImage() {
        return image;
    }
    /**
     * @param start_x the start_x to set
     */
    public void setStart_x(int start_x) {
        this.start_x = start_x;
    }
    /**
     * @param start_y the start_y to set
     */
    public void setStart_y(int start_y) {
        this.start_y = start_y;
    }
    /**
     * @param end_x the end_x to set
     */
    public void setEnd_x(int end_x) {
        this.end_x = end_x;
    }
    /**
     * @param end_y the end_y to set
     */
    public void setEnd_y(int end_y) {
        this.end_y = end_y;
    }
    /**
     * @param radius the radius to set
     */
    public void setRadius(int radius) {
        this.radius = radius;
    }
    /**
     * @param image the image to set
     */
    public void setImage(Image image) {
        this.image = image;

        this.circle.setFill(new ImagePattern (this.image));
    }
    public void move () {
        if(this.start_x<bounds.getMaxX()/2) {


            timeline.setAutoReverse(false);
            KeyValue xKV = new KeyValue(this.circle.centerXProperty(), this.end_x);
            KeyValue yKV = new KeyValue(this.circle.centerYProperty(), this.end_y, new Interpolator() {
                @Override
                protected double curve(double t) {
                    return -4 * (t - .5) * (t - .5) + 1;

                }
            });

            KeyFrame xKF = new KeyFrame(Duration.millis(this.speed), xKV);
            KeyFrame yKF = new KeyFrame(Duration.millis(this.speed), yKV);
            timeline.getKeyFrames().addAll(xKF, yKF);
            timeline.play();

        }

        else
        {


            timeline2.setAutoReverse(false);
            KeyValue xKV = new KeyValue(this.circle.centerXProperty(), this.end_x-400);
            KeyValue yKV = new KeyValue(this.circle.centerYProperty(), this.end_y, new Interpolator() {
                @Override
                protected double curve(double t) {
                    return -4 * (t - .5) * (t - .5) + 1;

                }
            });

            KeyFrame xKF = new KeyFrame(Duration.millis(this.speed), xKV);
            KeyFrame yKF = new KeyFrame(Duration.millis(this.speed), yKV);
            timeline2.getKeyFrames().addAll(xKF, yKF);
            timeline2.play();

        }
    }

    @Override
    public void resume()
    {
    	timeline.play();
    	timeline2.play();
    }
    @Override
    public void stopMoving()
    {

    	timeline.pause();
    	timeline2.pause();

    }
	@Override
	public Circle Circle() {
		return this.circle;

	}
	@Override
	public String toString()
	{
		return "FatalBomb";
	}

}
