package View;

import javafx.animation.RotateTransition;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Rotate;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainMenu {

    Scene mainmenuscene;
    Stage stage;
    Classic classic;
    public Scene getMainmenuscene() {
        return mainmenuscene;
    }

    public void setMainmenuscene(Scene mainmenuscene) {
        this.mainmenuscene = mainmenuscene;
    }


    public void PrepareMainmenuscene()
    {
        Screen screen = Screen.getPrimary();
        Rectangle2D screenbounds = screen.getBounds();
        Group root = new Group();
        mainmenuscene = new Scene(root, screenbounds.getWidth(), screenbounds.getHeight());
        mainmenuscene.setFill(new ImagePattern(new Image("Assets/background.png")));

        Circle watermeloncircle = new Circle();
        watermeloncircle.setRadius(100);
        watermeloncircle.setFill(new ImagePattern(new Image("Assets/watermelon.png")));
        watermeloncircle.setLayoutX(400);
        watermeloncircle.setLayoutY(400);

        Circle bananacircle = new Circle();
        bananacircle.setRadius(100);
        bananacircle.setFill(new ImagePattern(new Image("Assets/banana.png")));
        bananacircle.setLayoutX(800);
        bananacircle.setLayoutY(400);


        DropShadow dropShadow = new DropShadow();
        dropShadow.setOffsetX(10);
        dropShadow.setOffsetY(10);
        dropShadow.setColor(Color.BLACK);

        bananacircle.setEffect(dropShadow);
        watermeloncircle.setEffect(dropShadow);

        Circle cursor = new Circle(10, 10, 10, Color.GREEN);
        Image imagecur = new Image("Assets/blade.png");
        mainmenuscene.setCursor(new ImageCursor(imagecur));

        //banana rotate trans
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(3), root);
        rotateTransition.setFromAngle(360);
        rotateTransition.setToAngle(0);
        rotateTransition.setAutoReverse(false);
        rotateTransition.setCycleCount(10000000);
        rotateTransition.setNode(bananacircle);
        rotateTransition.play();

        RotateTransition rotateTransition2 = new RotateTransition(Duration.seconds(3), root);
        rotateTransition2.setFromAngle(0);
        rotateTransition2.setToAngle(360);
        rotateTransition2.setAutoReverse(false);
        rotateTransition2.setCycleCount(10000000);
        rotateTransition2.setNode(watermeloncircle);
        rotateTransition2.play();


        root.getChildren().add(watermeloncircle);
        root.getChildren().add(bananacircle);

        mainmenuscene.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                cursor.setCenterX(event.getSceneX());
                cursor.setCenterY(event.getSceneY());
                if (cursor.getBoundsInParent().intersects(watermeloncircle.getBoundsInParent())) {
                    classic.PrepareClassicScene();
                    stage.setScene(classic.getScene());
                }
                }
        });
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setClassic(Classic classic) {
        this.classic = classic;
    }
}
